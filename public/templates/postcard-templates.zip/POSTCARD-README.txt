AIRARC / A6 POSTCARD TEMPLATE

Finished: 148 x 105 mm (landscape).
Bleed: 3 mm on each side; full artwork is 154 x 111 mm.
Safe text/logo region: 142 x 99 mm (3 mm inside trim).

AI artboards: example front, example back, blank front, blank back. Artboards are the finished size; background art extends 3 mm beyond each edge. When preparing a print PDF, use the artboards and specify a 3 mm bleed. Confirm PDF specification and stock with the printer.

WEB: hide guides and export only a finished-size artboard. Use SVG or PNG with a 148:105 ratio (e.g. 1776 x 1260 pixels); do not upload the 154 x 111 print-bleed canvas. The website shows front and back artwork on the two sides of one postcard.

Source: https://centralprinting.co.uk/product/a6-postcards/
Verified 18 October 2026. The supplier lists 148 x 105 mm, 3 mm bleed and a 3 mm minimum text/logo margin.

All artwork is vector. Native AI files were created in Adobe Illustrator 29.8.11, with PDF compatibility enabled. The AI preserves the author's editable text and layers. The GUIDES layer is locked and nonprinting in AI. SVG guides are ordinary vector strokes in a separate named group: hide/delete 90 GUIDES before production export. The web-artwork files already contain outlined type and have no guides, external fonts or embedded images.

Color: RGB #4d85c5, white and black. Convert a production copy to the printer's requested CMYK/profile; RGB-to-CMYK appearance depends on stock, process and profile. Keep the supplied AI as your editable master.

Updated from the author-edited AI on 19 October 2026. SVG lettering is outlined; edit text in the native AI master.
