AIRARC / AVIATION PIN SERIES

Original author-edited Illustrator master from Designs / Pins.
Seven designs: Attitude, Heading, Tail Fin, Runway 27, Gate 07, Routes, Globe. Blank artboards 4, 9 and 10 are omitted from the website and clean SVG exports; the original AI is preserved unchanged.
Finished visible face: diameter 58 mm. AI artboards: 70 x 70 mm for the supplier-specific cut/wrap template; safe area diameter 52 mm.
web-artwork SVGs are centered 58 x 58 mm crops (6 mm removed from each edge), with outlined text and no guides. The website clips these to a circle.
AI retains the editable artwork and full wrap area. Hide the nonprinting GUIDES layer for export.
Confirm the 70 mm cutting die, wrap, safe margin and color profile with your manufacturer before production.
