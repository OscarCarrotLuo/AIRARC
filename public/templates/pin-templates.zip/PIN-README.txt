AIRARC / 58 MM ROUND BUTTON PIN TEMPLATE

Visible face: diameter 58 mm.
Cut / wrap artwork: diameter 70 mm, centered in a 70 x 70 mm artboard.
Safe text/logo area: diameter 52 mm (a conservative 3 mm inset from the visible face).
Wrap: 6 mm radial band between the 58 mm face and 70 mm cut.

AI artboards: example printed face and blank printed face. Continue backgrounds across the full 70 mm cut circle. The 70 mm cut is supplier-specific, not a universal standard for all 58 mm machines. Confirm the exact die, wrap and safe region with your supplier before production. The backside is metal and is not a second printed face.

WEB: hide guides and export the centered 58 x 58 mm square face crop; offset 6 mm from every edge of the 70 mm artboard. Use SVG or PNG, e.g. 1160 x 1160 pixels. Do not upload the full 70 mm cut canvas. The website clips the square crop to a circle.

Source: https://mybadgestudio.com/blog/guide-to-58mm-button-badge-template
Verified 18 October 2026. This supplier specifies a 58 mm face and 70 mm cut. The 52 mm safe circle is our conservative layout recommendation.

All artwork is vector. Native AI files were created in Adobe Illustrator 29.8.11, with PDF compatibility enabled. Text is editable Arial / Arial Bold. The GUIDES layer is locked and nonprinting in AI. SVG guides are ordinary vector strokes in a separate named group: hide/delete GUIDES-HIDE-BEFORE-EXPORT before production export. The web-artwork files already contain outlined type and have no guides, external fonts or embedded images.

Color: RGB #4d85c5, white and black. Convert a production copy to the printer's requested CMYK/profile; RGB-to-CMYK appearance depends on stock, process and profile. Keep the supplied AI as your editable master.
