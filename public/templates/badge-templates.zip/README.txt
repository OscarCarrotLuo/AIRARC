AIRARC / BADGE AND LANYARD

Original author-edited Illustrator masters from Designs / Name Card.
Badge: 54 x 85.6 mm finished, 3 mm bleed. Four artboards: front, back and two blanks.
Lanyard: 900 x 20 mm unfolded, 2 mm bleed. Four artboards: A, B and two blanks.
AI files preserve editable text and layers. Hide the nonprinting GUIDES / HOLES layers when exporting.
web-artwork SVGs are clean finished-size artboards with outlined text. Front/back and A/B are ordered 1/2; blanks are 3/4.
Upload badge faces at 54:85.6, or horizontal straps at 900:20. Do not include crop marks or bleed in website images.
Confirm materials, color profile, trim, holes and seam allowances with your manufacturer before production.
